#ifndef CARD_TYPE_H
#define CARD_TYPE_H

enum CardType {
	TWO = 0,
	THREE,
	FOUR,
	FIVE,
	SIX,
	SEVEN,
	EIGHT,
	NINE,
	TEN,
	ACE,
	KING,
	QUEEN,
	JACK, 
	NONE
};

#endif // !CARD_TYPE_H
